import { motion } from 'framer-motion';
import { Clock, MapPin, Sun, Moon, Sunset, Coffee, Utensils, Star, Info } from 'lucide-react';

interface TimelineItineraryProps {
    dayPlans: any[];
    formatCurrency: (amount: number) => string;
}

const TimelineItinerary = ({ dayPlans, formatCurrency }: TimelineItineraryProps) => {

    const getTimeIcon = (time: string) => {
        switch (time) {
            case 'Sunrise': return <Sun size={18} className="text-orange-400" />;
            case 'Morning': return <Coffee size={18} className="text-yellow-600" />;
            case 'Midday': return <Sun size={18} className="text-yellow-500" />; // Should use a different icon ideally
            case 'Sunset': return <Sunset size={18} className="text-orange-500" />;
            case 'Evening': return <Moon size={18} className="text-indigo-400" />;
            default: return <Clock size={18} />;
        }
    };

    return (
        <div className="space-y-12">
            {dayPlans.map((day, dayIndex) => (
                <motion.div
                    key={day.day}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: dayIndex * 0.1 }}
                    className="relative"
                >
                    {/* Day Header */}
                    <div className="flex items-center gap-4 mb-8 sticky top-20 z-10 bg-background/95 backdrop-blur-sm py-4 border-b border-border/50">
                        <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary font-bold text-xl ring-4 ring-background">
                            {day.day}
                        </div>
                        <div>
                            <h3 className="text-xl font-bold text-foreground">{day.title}</h3>
                            <p className="text-sm text-muted-foreground">{day.description}</p>
                        </div>
                        <div className="ml-auto text-sm font-medium text-muted-foreground bg-secondary/50 px-3 py-1 rounded-full">
                            Est. {formatCurrency(day.dailySpend)}
                        </div>
                    </div>

                    {/* Timeline */}
                    <div className="relative pl-6 md:pl-8 ml-6 border-l-2 border-border/50 space-y-8 pb-8">
                        {day.activities.map((activity: any, actIndex: number) => (
                            <motion.div
                                key={actIndex}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: (dayIndex * 0.2) + (actIndex * 0.1) }}
                                className="relative"
                            >
                                {/* Timeline Node */}
                                <div className="absolute -left-[39px] md:-left-[41px] top-6 w-5 h-5 rounded-full border-4 border-background bg-primary shadow-sm z-10 ring-2 ring-primary/20" />

                                {/* Card */}
                                <div className="bg-card rounded-2xl border border-border overflow-hidden hover:shadow-lg transition-shadow duration-300 group">
                                    <div className="flex flex-col md:flex-row">
                                        {/* Image Section */}
                                        <div className="md:w-48 h-48 md:h-auto relative shrink-0 overflow-hidden">
                                            {activity.image ? (
                                                <img
                                                    src={activity.image}
                                                    alt={activity.title}
                                                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                                                />
                                            ) : (
                                                <div className="w-full h-full bg-muted flex items-center justify-center text-muted-foreground">
                                                    <MapPin size={24} />
                                                </div>
                                            )}

                                            <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-md text-white px-2 py-1 rounded-md text-xs font-bold flex items-center gap-1.5 border border-white/10">
                                                {getTimeIcon(activity.time)} {activity.time}
                                            </div>
                                        </div>

                                        {/* Content Section */}
                                        <div className="p-5 flex-grow">
                                            <div className="flex justify-between items-start mb-2">
                                                <div>
                                                    <h4 className="text-lg font-bold text-foreground group-hover:text-primary transition-colors">
                                                        {activity.title}
                                                    </h4>
                                                    <div className="flex flex-wrap gap-2 mt-1">
                                                        <span className="text-xs bg-secondary text-secondary-foreground px-2 py-0.5 rounded-md font-medium">
                                                            {activity.duration}
                                                        </span>
                                                        {activity.bestWindow && (
                                                            <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded-md font-medium flex items-center gap-1 border border-yellow-200">
                                                                <Sun size={10} />
                                                                Best: {activity.bestWindow}
                                                            </span>
                                                        )}
                                                        {activity.crowdLevel && (
                                                            <span className={`text-xs px-2 py-0.5 rounded-md border ${activity.crowdLevel === 'High' ? 'border-red-200 text-red-600 bg-red-50' :
                                                                activity.crowdLevel === 'Low' ? 'border-green-200 text-green-600 bg-green-50' :
                                                                    'border-orange-200 text-orange-600 bg-orange-50'
                                                                }`}>
                                                                {activity.crowdLevel} Crowd
                                                            </span>
                                                        )}
                                                    </div>

                                                    {/* Crowd Timeline Visualization */}
                                                    {activity.crowdTimeline && (
                                                        <div className="mt-3">
                                                            <div className="flex items-center gap-1 mb-1">
                                                                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Crowd Forecast</span>
                                                            </div>
                                                            <div className="flex items-end gap-1 h-8">
                                                                {activity.crowdTimeline.map((slot: any, index: number) => (
                                                                    <div key={index} className="flex flex-col items-center gap-1 flex-1 group/bar">
                                                                        <div
                                                                            className={`w-full rounded-sm transition-all relative ${slot.level === 'High' ? 'bg-red-400 h-6' :
                                                                                    slot.level === 'Medium' ? 'bg-orange-300 h-4' :
                                                                                        'bg-green-300 h-2'
                                                                                }`}
                                                                        >
                                                                            {/* Tooltip */}
                                                                            <div className="absolute bottom-full mb-1 left-1/2 -translate-x-1/2 bg-black/80 text-white text-[10px] px-1.5 py-0.5 rounded opacity-0 group-hover/bar:opacity-100 whitespace-nowrap z-10 pointer-events-none">
                                                                                {slot.level}
                                                                            </div>
                                                                        </div>
                                                                        <span className="text-[9px] text-muted-foreground">{slot.time}</span>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                                <span className="text-sm font-bold text-muted-foreground">
                                                    {activity.cost > 0 ? formatCurrency(activity.cost) : 'Free'}
                                                </span>
                                            </div>

                                            <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                                                {activity.description}
                                            </p>

                                            {activity.reason && (
                                                <div className="bg-accent/10 p-3 rounded-xl flex items-start gap-2 border border-accent/20">
                                                    <Star size={14} className="text-accent mt-0.5 shrink-0 fill-accent" />
                                                    <p className="text-xs text-foreground/80 font-medium">
                                                        <span className="text-accent font-bold">Why here: </span>
                                                        {activity.reason}
                                                    </p>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </motion.div>
            ))}
        </div>
    );
};

export default TimelineItinerary;
